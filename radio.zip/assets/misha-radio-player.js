(() => {
 'use strict';
 const $=id=>document.getElementById(id), audio=$('audio');
 let stations=[],current=0,hls=null,wanted=false,generation=0,fallback=false;
 const message=text=>{$('status').textContent=text;};
 function controls(playing){
  $('player').classList.toggle('is-playing',playing);
  $('play').setAttribute('aria-pressed',String(playing));
  $('play').setAttribute('aria-label',playing?'Приостановить радио':'Включить радио');
  $('play-icon').setAttribute('d',playing?'M6 5h4v14H6zm8 0h4v14h-4z':'M8 5v14l11-7z');
  $('action').textContent=playing?'Вы слушаете эфир':'Слушать эфир';
 }
 function reset(){generation++;wanted=false;audio.pause();if(hls){hls.destroy();hls=null;}audio.removeAttribute('src');audio.load();controls(false);}
 async function play(token){try{await audio.play();}catch(error){if(token!==generation||error.name==='AbortError')return;wanted=false;controls(false);message('Нажмите воспроизведение, чтобы включить эфир.');}}
 function start(){
  if(!stations.length)return;
  reset();wanted=true;fallback=false;
  const token=generation,station=stations[current];message('Подключаемся к '+station.title+'…');
  function useAAC(){if(token!==generation||!wanted||fallback)return;fallback=true;if(hls){hls.destroy();hls=null;}audio.src=station.aac;audio.load();play(token);}
  if(audio.canPlayType('application/vnd.apple.mpegurl')){audio.src=station.hls;play(token);}
  else if(window.Hls&&Hls.isSupported()){
   hls=new Hls({startLevel:0,maxBufferLength:20,backBufferLength:10,enableWorker:true});
   hls.on(Hls.Events.MANIFEST_PARSED,()=>{if(token===generation&&wanted)play(token);});
   hls.on(Hls.Events.ERROR,(_event,data)=>{if(data.fatal)useAAC();});
   hls.loadSource(station.hls);hls.attachMedia(audio);
  }else useAAC();
 }
 function choose(index,autoplay){
  reset();current=(index+stations.length)%stations.length;
  const station=stations[current];$('channel').value=station.id;
  $('station-title').textContent=station.title;$('cover-title').textContent=station.title;$('station-description').textContent=station.description;
  document.querySelector('.cover-number').textContent=String(current+1).padStart(2,'0')+' / 08';
  $('stream-link').href=station.hls;
  document.querySelectorAll('.channels button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.id===station.id)));
  message('Готов к воспроизведению');if(autoplay)start();
 }
 $('play').addEventListener('click',()=>{if(wanted){reset();message('Эфир на паузе');}else start();});
 $('channel').addEventListener('change',()=>choose(stations.findIndex(s=>s.id===$('channel').value),true));
 $('previous').addEventListener('click',()=>{if(stations.length)choose(current-1,true);});
 $('next').addEventListener('click',()=>{if(stations.length)choose(current+1,true);});
 audio.addEventListener('playing',()=>{if(wanted){controls(true);message('Прямой эфир · Radio Record');}});
 audio.addEventListener('waiting',()=>{if(wanted)message('Загружаем звук…');});
 audio.addEventListener('error',()=>{if(wanted&&(!hls||fallback)){wanted=false;controls(false);message('Станция недоступна. Выберите другой канал или повторите.');}});
 audio.volume=Number($('volume').value);
 $('volume').addEventListener('input',()=>{audio.volume=Number($('volume').value);$('volume-value').textContent=Math.round(audio.volume*100)+'%';});
 $('year').textContent=new Date().getFullYear();
 fetch('/assets/channels-misha.json?v=1',{cache:'no-cache'}).then(r=>{if(!r.ok)throw Error('catalog');return r.json();}).then(data=>{
  stations=data;stations.forEach((station,index)=>{
   const option=document.createElement('option');option.value=station.id;option.textContent=station.title;$('channel').append(option);
   const button=document.createElement('button');button.type='button';button.textContent=station.title;button.dataset.id=station.id;
   button.addEventListener('click',()=>choose(index,true));$('channels').append(button);
  });choose(0,false);
 }).catch(()=>message('Не удалось загрузить станции. Обновите страницу.'));
})();
